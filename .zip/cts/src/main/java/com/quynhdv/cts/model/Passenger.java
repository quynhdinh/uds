package com.quynhdv.cts.model;

import java.time.LocalDate;

import org.json.JSONObject;

public class Passenger {

    private int id;
    private String firstName, lastName, phoneNumber, trainStation;
    private LocalDate dateOfBirth, dateTimeBoarded;

    public Passenger(int id, String firstName, String lastName, String phoneNumber, String trainStation,
            LocalDate dateOfBirth, LocalDate dateTimeBoarded) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.trainStation = trainStation;
        this.dateOfBirth = dateOfBirth;
        this.dateTimeBoarded = dateTimeBoarded;
    }

    @Override
    public String toString() {
        return "Passenger{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", trainStation='" + trainStation + '\'' +
                ", dateOfBirth=" + dateOfBirth +
                ", dateTimeBoarded=" + dateTimeBoarded +
                '}';
    }

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public LocalDate getDateTimeBoarded() {
        return dateTimeBoarded;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getTrainStation() {
        return trainStation;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public JSONObject toJSON() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("passengerId", id);
        jsonObject.put("firstName", firstName);
        jsonObject.put("lastName", lastName);
        jsonObject.put("phoneNumber", (phoneNumber != null) ? phoneNumber : "null");
        jsonObject.put("trainStation", (trainStation != null) ? trainStation : "null");
        jsonObject.put("dateOfBirth", dateOfBirth);
        jsonObject.put("dateTimeBoarded", dateTimeBoarded);
        return jsonObject;
    }

    public int getAge() {
        LocalDate today = LocalDate.now();
        int age = today.getYear() - dateOfBirth.getYear();
        if (today.getDayOfYear() < dateOfBirth.getDayOfYear()) {
            age--;
        }
        return age;
    }
}
