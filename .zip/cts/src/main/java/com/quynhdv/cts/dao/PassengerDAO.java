package com.quynhdv.cts.dao;


import java.time.LocalDate;

import com.quynhdv.cts.model.Passenger;

public class PassengerDAO {
    private static PassengerDAO instance;

    private Passenger[] passengers = null;

    // Private constructor to prevent instantiation
    private PassengerDAO() {
    }

    // Public method to provide access to the single instance
    public static synchronized PassengerDAO getInstance() {
        if (instance == null) {
            // Lazy initialization of the singleton instance
            // This ensures that the instance is created only when it is needed.
            instance = new PassengerDAO();
        }
        return instance;
    }

    private void loadData() {
        this.passengers = new Passenger[] {
            new Passenger(0, "Daniel", "Agar", "(641) 123-1019", "Piccadilly", LocalDate.of(1987, 3, 21), LocalDate.of(2025, 7, 19)),
            new Passenger(1, "Anna", "Smith", "(301) 817-1199", "KingCross Road", LocalDate.of(2001, 12, 7), LocalDate.of(2025, 7, 22)),
            new Passenger(2, "Bob", "Costas", null, "Navy Mall", LocalDate.of(2008, 2, 28), LocalDate.of(2025, 11, 17))
        };
    }

    /**
     * Fetches the Patients data from the data source.
     * If the array is null or empty, loads the data first.
     * @return patients the array of Patients
     */
    public Passenger[] getPassengers() {
        if (passengers == null || passengers.length == 0) {
            loadData();
        }
        return passengers;
    }
}