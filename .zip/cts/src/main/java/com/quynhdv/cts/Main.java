package com.quynhdv.cts;

import com.quynhdv.cts.model.Passenger;
import com.quynhdv.cts.service.PassengerService;
import com.quynhdv.cts.util.JSONConverterUtil;

public class Main {
    public static void main(String[] args) {

        System.out.println("Hello! Welcome to the Commuter Train Scheduling App!");
        System.out.println("__________________________________________________________________________");
        // Process data
        PassengerService passengersService = new PassengerService();
        Passenger[] passengers = passengersService.getPassengerOlderThan20();
        String passengersJson = JSONConverterUtil.convertPassengerArrayToJSON(passengers);
        System.out.println(passengersJson);

        System.out.println("\nApplication tasks completed successfully!");
        System.out.println("Exiting the application...Goodbye!");
    }
}