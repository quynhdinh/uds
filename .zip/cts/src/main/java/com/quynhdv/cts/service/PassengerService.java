package com.quynhdv.cts.service;

import java.util.Comparator;

import com.quynhdv.cts.dao.PassengerDAO;
import com.quynhdv.cts.model.Passenger;

public class PassengerService {
    private PassengerDAO passengerDAO;

    public PassengerService() {
        this.passengerDAO = PassengerDAO.getInstance();
    }

    /**
     * Fetches the passengers data from the DAO.
     * @return passengers the array of Passengers
     */
    public Passenger[] getPassengers() {
        return passengerDAO.getPassengers();
    }

    // get people older than 20 and sort by firstname
    public Passenger[] getPassengerOlderThan20() {
        Passenger[] passengers = passengerDAO.getPassengers();
        return java.util.Arrays.stream(passengers)
                .filter(p -> p.getDateOfBirth().isBefore(java.time.LocalDate.now().minusYears(20)))
                .sorted(Comparator.comparing(Passenger::getFirstName))
                .toArray(Passenger[]::new);
    }
}
