package com.quynhdv.cts.util;

import java.util.Arrays;

import org.json.JSONArray;

import com.quynhdv.cts.model.Passenger;

public class JSONConverterUtil {
    public static String convertPassengerArrayToJSON(Passenger[] passengers) {
        JSONArray jsonArray = new JSONArray();
        Arrays.stream(passengers).forEach(passenger -> {
            jsonArray.put(passenger.toJSON());
        });
        return jsonArray.toString(2);
    }
}