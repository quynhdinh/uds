# Java 21
# Following the following steps
# mvn clean install
# mvn package
# java -jar target/cts.jar